package mainpackage;


import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ClickMap extends Mapper<LongWritable, Text, Text, IntWritable>{
	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
	{
		String line = value.toString();
		
		String findStr = "hadoop";
		
		/*
		 * We are using StringUtils, Please make sure you added  commons-lang3-3.0.jar in build path 
		 * 
		 */
		
		
		line = StringUtils.lowerCase(line);
		int count=StringUtils.countMatches(line, findStr);
		
		int i=0;
		
		//while(i<count)
		//{
			context.write(new Text(String.valueOf("hadoop")), new IntWritable(count));
			//i++;
		//}
		
		
	}
}