package mainpackage;


import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ClickMap extends Mapper<LongWritable, Text, Text, IntWritable>{
	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
	{
		String line = value.toString();
		/*String parts[]=line.split(" ");
		//System.out.println(parts[0]);
		//Pattern p = Pattern.compile("\\[(.*?)\\]");
		//Matcher m = p.matcher(line);

		//while(m.find()) {
			Pattern p1 = Pattern.compile("\\:(.*?)\\:");
			Matcher m1 = p1.matcher(m1.group(1));
			while(m1.find()) {
			System.out.println(m1.group(1));
			 //System.out.println(parts[0]);
				//context.write(new Text(String.valueOf(parts[0])), new IntWritable(1));
				//break;
			//}
		//}
		
	}
}*/
		
		Pattern p = Pattern.compile("\\[(.*?)\\]");
		Matcher m = p.matcher(line);

		while(m.find())
		{
		    //System.out.println(m.group(1));

			Pattern p1 = Pattern.compile("\\:(.*?)\\:");
			Matcher m1 = p1.matcher(m.group(1));
			while(m1.find())
			{
		    System.out.println(m1.group(1));
			context.write(new Text(String.valueOf(m1.group(1))), new IntWritable(1));
			}
		/*char[] c_arr = line.toCharArray();
		
		for (char c : c_arr)
		{
			System.out.println(c);
			context.write(new Text(String.valueOf(c)), new IntWritable(1));
		}
		
	}  
}*/
}
}
}