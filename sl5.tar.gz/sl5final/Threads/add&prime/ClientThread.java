import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import java.io.IOException;


class ClientThread implements Runnable
{

   private Socket s;

  public ClientThread(Socket _s)
{
  this.s=_s;
}


public void run()
{

  try
{
DataInputStream din= new DataInputStream(s.getInputStream());
DataOutputStream dout= new DataOutputStream(s.getOutputStream());
BufferedReader br= new BufferedReader(new InputStreamReader(System.in));

String str=" ",str2=" ";

while(!str.equals("stop"))
{
   str=din.readUTF();
   System.out.println("client says:"+str); 
   int a=Integer.parseInt(str);
	int d=0,sum=0;
	while(a!=0)
       {
            d=a%10;
           a=a/10;
            sum=sum+d;
       }
   
  
  str=Integer.toString(sum);
 dout.writeUTF("addition "+str);
int str1=Integer.parseInt(str);


 int m=str1/2; 
   int i=0,flag=0;
   
  for(i=2;i<=m;i++)
{    
   if(str1%i==0)
   {    
     flag=1;
   str2=Integer.toString(str1);
	
     dout.writeUTF("number is not prime"+str2); 

     break;    
   }
}    
if(flag==0)

dout.writeUTF("number is prime"+str2);   

 }  
din.close();
s.close();

}//end try

catch(IOException e)
{
   e.printStackTrace();
}

}
//end run
}//end class


