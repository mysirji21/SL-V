import java.io.IOException;
import java.net.Socket;
import java.net.ServerSocket;


class Server
{

  static ServerSocket ss= null;
  public static void main(String args[])
{
  

System.out.println("server is now running");

 Runnable listen= new Runnable()


{
  public void run()
{
   int i=1;
 try
{
  System.out.println("listening at port 4053");

   ss= new ServerSocket(4053);

  while(true)
{
  Socket s=ss.accept();

  if(s!= null && i<=10)
{
  System.out.println(" new thread is created"+i);
   ++i;

new Thread(new ClientThread(s)).start();
}//end if

else
  break;

}//end while
ss.close();
}//end try

catch(IOException e)
{
  e.printStackTrace();

}

}//end run
};//end runnable

new Thread(listen).start();

}

}

  

