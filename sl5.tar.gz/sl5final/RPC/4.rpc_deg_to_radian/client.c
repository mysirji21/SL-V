#include <stdlib.h>
#include <stdio.h>
#include <rpc/rpc.h>
#include "degToradian.h"

main(argc, argv)
int argc;
char **argv;
{
	CLIENT *cl;	/* rpc handle */
	char *server;
	float *num;
	float *result;

	if (argc != 2) {
		fprintf(stderr, "usage:  %s hostname\n", argv[0]);
		exit(1);
	}
	server = argv[1];	/* get the name of the server */

	num = (float *)malloc(sizeof(float));
	result = (float *)malloc(sizeof(float));

	/* create the client handle */
	if ((cl=clnt_create(server, FACT_PROG, FACT_VERS, "udp")) == NULL) 
	{
		/* failed! */
		clnt_pcreateerror(server);
		exit(1);
	}

	printf("\nEnter the value in degree which u want to convert into radian: ");
	scanf("%f",num);

	/* call the procedure bin_date */
	if ((result=fact_1(num, cl))==NULL) {
		/* failed ! */
		clnt_perror(cl, server);
		exit(1);
	}
	printf(" radian value returned from server is : %f\n", *result);

	clnt_destroy(cl);	/* get rid of the handle */
	exit(0);
}
