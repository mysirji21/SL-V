#include <rpc/rpc.h>
#include "degToradian.h"

float *fact_1_svc(float *num, struct svc_req *rqstp)
{
	float radian ;

	radian=((*num)*(3.14))/180;

	return &radian;
}
