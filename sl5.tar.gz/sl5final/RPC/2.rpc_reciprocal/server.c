#include <rpc/rpc.h>
#include "reciprocal.h"

float *fact_1_svc(float *num, struct svc_req *rqstp)
{
	
	float  temp;
		temp=(1/(*num));

	return &temp;
}
