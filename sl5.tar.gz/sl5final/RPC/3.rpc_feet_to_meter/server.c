#include <rpc/rpc.h>
#include "feetTometer.h"

float *fact_1_svc(float *num, struct svc_req *rqstp)
{
	float meter ;

	meter=(*num)/3.28;

	return &meter;
}
