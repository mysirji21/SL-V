

#include "mpi.h" 
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX 1000

int main( int argc, char **argv ) 
{ 
    MPI_Comm client; 
    MPI_Status status; 
    char port_name[MPI_MAX_PORT_NAME]; 
    char str[MAX], ch, temp; 
    int  size,i=0;
float num;
	float reciprocal;
     
 
	MPI_Init( &argc, &argv ); 
    MPI_Comm_size(MPI_COMM_WORLD, &size); 
    
 	if (size != 1)
 	{
	 	fprintf(stderr, "Server too big");
	 	exit(EXIT_FAILURE);
 	} 
    
    MPI_Open_port(MPI_INFO_NULL, port_name); 
   	printf("Server running at %s\n", port_name); 
    
         MPI_Comm_accept( port_name, MPI_INFO_NULL, 0, MPI_COMM_WORLD, &client ); 
         MPI_Recv( &num, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, client, &status ); 
         
                	 
           printf("\nReceived  : %f\n", num);
					     
	
        reciprocal=(1/num);

						 //send tag=1 to indicate end of string
        MPI_Send(&reciprocal, 1, MPI_FLOAT, 0, 0, client); 
								
    MPI_Comm_disconnect( &client ); 

    MPI_Finalize(); 
                        return 0; 
}
