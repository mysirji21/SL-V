//MPI_client.c

#include "mpi.h"  
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX 1000
 
int main( int argc, char **argv ) 
{ 
     MPI_Comm server; 
     MPI_Status status; 
     char port_name[MPI_MAX_PORT_NAME], str[MAX], ch; 
    
     int i, flag, tag;
	float num;
     float meter;
 
	 MPI_Init( &argc, &argv ); 
        strcpy(port_name, argv[1] );
 
  	 MPI_Comm_connect( port_name, MPI_INFO_NULL, 0, MPI_COMM_WORLD, &server ); 
 
 	  // accept input string
	        printf("\nEnter the feet :\n");
	  scanf("%f",&num); 	
             //num = 90;

	 // Sending done
	 MPI_Send(&num, 1, MPI_INT, 0, 0, server);
	
	 // Display reversed string

        MPI_Recv(&meter, 1, MPI_FLOAT, MPI_ANY_SOURCE, MPI_ANY_TAG, server, &status);


	
 	printf("\nmeter is : %f\n", meter); 

    MPI_Comm_disconnect(&server); 
    MPI_Finalize(); 
    
  return 0; 
} 
