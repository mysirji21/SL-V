
import java.rmi.*;  
import java.rmi.server.*;  
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
@SuppressWarnings("serial")
public class ConcatRemote extends UnicastRemoteObject implements Concater{  

	protected ConcatRemote() throws RemoteException
	{
		super();
	}

	public String strrev(String s1, String s2) throws RemoteException
	{
	System.out.println("Client says:: ");
	System.out.println(s1);
        System.out.println(s2);

	String st1=new StringBuffer(s1).reverse().toString();
        
System.out.println(st1);
System.out.println(s2);

        if(st1.equalsIgnoreCase(s2))
             return "reverse is present!!";
        else
             return "reverse is not present!!";     
    }  
}  
