
import java.rmi.*;  
import java.rmi.registry.*;  

public class MyServer
{  
	public static void main(String args[])
	{  
		try
		{  
			Concater stub=new ConcatRemote();  
			Naming.rebind("rmi://127.0.0.1:5004/Concater",stub); 
			//System.out.println(stub.strconcat(str,str1));  
		}
		catch(Exception e)
		{
			System.out.println(e);
		}  
	}  
}  

