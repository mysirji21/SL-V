
import java.rmi.*;  

public interface Concater extends Remote{

	public String strrev(String s1, String s2)throws RemoteException; 
}

