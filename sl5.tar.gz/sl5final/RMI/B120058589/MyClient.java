import java.rmi.*;
import java.rmi.server.*;

public class Client {
   public static void main(String args[]) throws RemoteException
   {
      try{
            
                 RemoteInterface stub=(RemoteInterface)Naming.lookup("rmi://192.168.15.26:2000/RemoteInterface");
                 int res=stub.vow("naman","aman");
                 
                 if(res!=-1)
                     System.out.println("Both String Contains "+res+" vowels");
                 else
                     System.out.println("String 1 and String 2 contains different no. of vowels");   
      }
      catch(Exception e){
               
               System.out.println(e);
      }
   }
}
