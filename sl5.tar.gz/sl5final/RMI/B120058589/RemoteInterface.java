import java.rmi.*;

public interface RemoteInterface extends Remote{
   
      public int vow(String x, String y) throws RemoteException;
}
