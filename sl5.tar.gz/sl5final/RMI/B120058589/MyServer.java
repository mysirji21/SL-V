import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

public class MyServer{
   public static void main(String args[]) throws RemoteException
   {
   
      try{
            	
               System.setProperty("java.rmi.server.hostname","192.168.15.26");
               RemoteInterface stub= new RemoteImplement();
               Naming.rebind("rmi://127.0.0.1:2000/RemoteInterface",stub);
      }
      catch(Exception e){
               
               System.out.println(e);
      }
   } 
}
