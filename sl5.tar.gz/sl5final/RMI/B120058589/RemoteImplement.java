import java.rmi.*;
import java.rmi.server.*;

public class RemoteImplement extends UnicastRemoteObject implements RemoteInterface{
   
      RemoteImplement() throws RemoteException{
         super();
      }
      
      public int vow(String x, String y) throws RemoteException
      {
            char ch;
            
            int vow_x=0,vow_y=0;
            
                   
            for(int i=0;i<x.length();i++)
            {
                 ch = x.charAt(i);
                 
                 if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' || ch=='A' || ch=='E' || ch=='O' || ch=='I' || ch=='U')
                     vow_x++;
            }
            for(int i=0;i<y.length();i++)
            {
                 ch = y.charAt(i);
                 
                 if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' || ch=='A' || ch=='E' || ch=='O' || ch=='I' || ch=='U')
                     vow_y++;
            }
            if(vow_x==vow_y)
               return vow_x;
            else
               return -1;
            
      }
}
