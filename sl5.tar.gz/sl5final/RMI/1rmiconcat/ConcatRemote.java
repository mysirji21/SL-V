
import java.rmi.*;  
import java.rmi.server.*;  
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
@SuppressWarnings("serial")
public class ConcatRemote extends UnicastRemoteObject implements Concater{  

	protected ConcatRemote() throws RemoteException
	{
		super();
	}

	public String strconcat(String s1, String s2) throws RemoteException
	{
	System.out.println("Client says:: " +s1);
	//System.out.println(s1);
        System.out.println(s2);
      return (s1+s2);
    }  
}  
