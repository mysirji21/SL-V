
import java.rmi.*;  
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.util.*;

public class Client
{  
	public static void main(String args[])
	{  
		//BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner sc =new Scanner(System.in);

		try
		{  
			Concater stub=(Concater)Naming.lookup("rmi://127.0.0.1:5001/Concater");  
			double a,b;			
			//str = br.readLine();
			//str1 = br.readLine();
			a=sc.nextDouble();
			b=sc.nextDouble();
			System.out.println(stub.powerFun(a,b)); 
				
		}catch(Exception e)
		{
			System.out.println(e);
		}  
	}  
}  

