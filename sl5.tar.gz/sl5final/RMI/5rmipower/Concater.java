
import java.rmi.*;  
import java.util.Scanner.*;
public interface Concater extends Remote{

	public double powerFun(double a,double b)throws RemoteException; 
}

