
import java.rmi.*;  
import java.rmi.server.*;  
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.util.Scanner.*;
@SuppressWarnings("serial")
public class ConcatRemote extends UnicastRemoteObject implements Concater{  

	protected ConcatRemote() throws RemoteException
	{
		super();
	}

	public double powerFun(double a,double b) throws RemoteException
	{
		System.out.println("Client says::");
		System.out.println("a="+a);
       	 	System.out.println("b="+b);
		double c=Math.pow(a,b);
     		 return (c);
    	}  
}  
